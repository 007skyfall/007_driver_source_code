cp *.so ~/rootfs/mjpg/
cp mjpg_streamer ~/rootfs/bin/
