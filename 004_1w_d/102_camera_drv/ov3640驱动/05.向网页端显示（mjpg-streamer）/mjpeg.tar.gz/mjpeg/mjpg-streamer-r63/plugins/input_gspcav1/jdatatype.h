#ifndef JDATATYPE_H
#define JDATATYPE_H

#define UINT16 unsigned short
#define INT16 signed short
#define UINT8 unsigned char
#define INT8 char
#define UINT32 unsigned int
#define INT32 int


#endif
